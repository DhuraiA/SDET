package sdetassignment_task2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

public class stringtodate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s;
Scanner sc=new Scanner(System.in);
System.out.print("Enter the string:");
s=sc.nextLine();
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d,yyyy",Locale.ENGLISH);
LocalDate date=LocalDate.parse(s,formatter);
System.out.println("Converted String:"+date);
	}

}
