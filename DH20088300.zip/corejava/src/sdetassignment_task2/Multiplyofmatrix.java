package sdetassignment_task2;

public class Multiplyofmatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]= {{2, 3, 4}, {5, 2, 3}};
		int b[][]= {{-4, 5, 3}, {5, 6, 3}};
		int c[][]=new int[2][3];
		System.out.print("Multiplication of two matrices:\n");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				c[i][j]=a[i][j]*b[i][j];
				System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
			}

		}