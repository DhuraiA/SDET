package corejavaassignments;

import java.util.Scanner;

public class Program4_Multiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner ar=new Scanner(System.in);
     System.out.print("Input number:\n");
     int b = ar.nextInt();
     for (int i=0;i<10;i++){
     System.out.println("Multiplication:"+b+"*"+(i+1)+"="+(b*(i+1)));
	}
	}
}
