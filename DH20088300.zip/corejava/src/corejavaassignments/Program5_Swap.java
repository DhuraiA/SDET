package corejavaassignments;

import java.util.Scanner;

public class Program5_Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner an=new Scanner(System.in);
  System.out.print("Enter the variable1:\n");
  int a=an.nextInt();
  System.out.print("Enter the variable2:\n");
  int b=an.nextInt();
  System.out.println("Input variables:\n"+"Var1:"+a+"\nVar2:"+b);
  int temp =a;
  a=b;
  b=temp;
  System.out.println("Swapped Variables:\n"+"Var1:"+a+"\nVar2:"+b);
	}

}
