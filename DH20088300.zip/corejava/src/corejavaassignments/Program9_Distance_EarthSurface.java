package corejavaassignments;

import java.util.Scanner;

public class Program9_Distance_EarthSurface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner qw=new Scanner(System.in);
System.out.print("Enter the latitude1 Corodinate:");
double la1=qw.nextDouble();
System.out.print("Enter the longitude1 Coordinate:");
double lo1=qw.nextDouble();
System.out.print("Enter the latitude2 Corodinate:");
double la2=qw.nextDouble();
System.out.print("Enter the longitude2 Coordinate:");
double lo2=qw.nextDouble();
System.out.println("Distance between two coordinates:"+dist(la1,lo1,la2,lo2)+"km");
	}
	public static double dist(double la1, double lo1, double la2, double lo2)
	{
		la1 = Math.toRadians(la1);
		lo1 = Math.toRadians(lo1);
		la2 = Math.toRadians(la2);
		lo2 = Math.toRadians(lo2);
		double rad=6371;
		return rad*Math.acos(Math.sin(la1)*Math.sin(la2) + Math.cos(la1)*Math.cos(la2)*Math.cos(lo1 - lo2));
	}

}
