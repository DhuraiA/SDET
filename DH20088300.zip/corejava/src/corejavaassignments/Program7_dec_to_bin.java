package corejavaassignments;

import java.util.Scanner;

public class Program7_dec_to_bin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int d,q,i=1,j;
int b[] = new int[100];
Scanner sc=new Scanner(System.in);
System.out.print("Input a Decimal:");
d=sc.nextInt();
q=d;
while(q != 0)
{
	b[i++]=q%2;
	q=q/2;
	}
System.out.print("Binary number is:");
for(j=i-1;j>0;j--)
{
	System.out.print(b[j]);
}
	}

}
