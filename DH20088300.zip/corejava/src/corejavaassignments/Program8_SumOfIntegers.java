package corejavaassignments;

import java.util.Scanner;

public class Program8_SumOfIntegers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner er=new Scanner(System.in);
System.out.print("Enter the integer:");
int d=er.nextInt();
System.out.print("Sum of Integers:"+sum(d));
	}
 public static int sum(long n)
{
	int r=0;
	while(n>0)
	{
		r+=n%10;
		n/=10;
		
	}
	return r;
}
}
