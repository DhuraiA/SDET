package corejavaassignments;

import java.util.Scanner;

public class Program6_Binary_add {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
long bin1,bin2;
int i=0, rem=0;
int[] sum = new int[20];
Scanner sw=new Scanner(System.in);
System.out.print("Input Binary number1:");
bin1 = sw.nextLong();
System.out.print("Input Binary number2:");
bin2 = sw.nextLong();
while(bin1 != 0 || bin2 != 0)
{
	sum[i++] = (int)((bin1 % 10+bin2 % 10+rem)%2);
	rem = (int)((bin1 % 10+bin2 % 10+rem)/2);
	bin1 = bin1/10;
	bin2 = bin2/10;
}
if (rem != 0)
{
	sum[i++] = rem;
}
--i;
System.out.println("Sum of two Binary numbers:");
while(i>=0)
{
	System.out.print(sum[i--]);
	}
	}

}
