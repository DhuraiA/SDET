package sdetassignment_task1;

import java.util.Scanner;

public class Reverse_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int s,i,j,t;
int a[] = new int[50];
Scanner sc=new Scanner(System.in);
System.out.print("Enter Array size:");
s=sc.nextInt();
System.out.print("Enter the Array elements:\n");
for(i=0;i<s;i++)
		{
			a[i]=sc.nextInt();
			
		}
		j=i-1;
		i=0;
		while(i<j)
		{
			t=a[i];
			a[i]=a[j];
			a[j]=t;
			i++;
			j--;
		}
		System.out.print("Reversed Array:\n");
		for(i=0;i<s;i++)
		{
			System.out.print(a[i]+" ");
		}

	}

}
