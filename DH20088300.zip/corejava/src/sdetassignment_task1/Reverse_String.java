package sdetassignment_task1;

import java.util.Scanner;

public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner as = new Scanner(System.in);
		System.out.print("Enter a String:");
			char[] let = as.nextLine().toCharArray();
		System.out.print("Reversed String:");
			for(int i=let.length-1;i>=0;i--)
		{
			System.out.print(let[i]);
		}
	}

}
