package sdetassignment_task1;

import java.util.Scanner;

public class Swap_Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int s,i;
Scanner sc=new Scanner(System.in);
System.out.print("Enter the number of Arrays:\n");
s=sc.nextInt();
int a[]=new int[s];
int b[]=new int[s];

for(i=0;i<s;i++)
{
	System.out.print("Enter the elements in array:\n");
	a[i]=sc.nextInt();
	b[i]=sc.nextInt();
}
System.out.print("After Swapping:\n");
for(i=0;i<s;i++)
{
	System.out.println(b[i]+" "+a[i]);
}
sc.close();
	}
}
